package Wk13;

public class Fourthloop{
  public static void main(String[] args){

    int counter = 1;
    while(counter <= 10){
        System.out.println("Loop Counter: "+counter);
        counter++;
    }

  }
}