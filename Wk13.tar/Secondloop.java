package Wk13;

public class Secondloop{
  public static void main(String[] args){

    int counter = 1;
    while(counter <= 20){
        System.out.println("My Second Loop");
        counter++;
    }

  }
}