package Wk14;

public class FifteenLoops{

    public static void main(String[] args){

        int counter = 1;

        while(counter <=15){
            System.out.println("Software Development 1");
            System.out.println("Computing and Digital Media");
            counter++;

        }
    }

}
