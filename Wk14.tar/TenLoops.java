package Wk14;

public class TenLoops{

    public static void main(String[] args){

        int counter = 1;

        while(counter <=10){
            System.out.println("Week 14");
            counter++;

        }
    }

}
